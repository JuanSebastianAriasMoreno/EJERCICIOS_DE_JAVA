package usta.sistemas;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        /*AUTHOR: Juan Sebastian Arias Moreno
          DATE: 16//03/2020
          DESCRIPTION: This software realizes many operations with strings
         */
        Scanner keyboard = new Scanner(System.in);
        String name;
        System.out.println("----------------------------------------");
        System.out.println("              SOFTSTRING");
        System.out.println("----------------------------------------");
        System.out.println("Input the name: ");
        name = keyboard.nextLine();
        if (name.indexOf("gomez")!= -1){
            System.out.println("Gomez already exists");
        }else{
            System.out.println("Gomez doesn´t exist");
        }
        System.out.println("The upper name is " +name.toUpperCase());
        System.out.println(name.replace("a", "@"));
        System.out.println(name.substring(7));
    }
}

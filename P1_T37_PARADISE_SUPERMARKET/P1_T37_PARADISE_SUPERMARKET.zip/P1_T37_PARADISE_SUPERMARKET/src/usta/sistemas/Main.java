package usta.sistemas;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Juan Sebastian Arias Moreno
	  DATE: 19/03/2020
	  DESCRIPTION: This software generate a bill of the supermarket paradise
	 */
        Scanner keyboard = new Scanner(System.in);
        int product1, product2, product3, product4, total_bruto;
        double total, iva;
        System.out.println("The software generate a bill of the supermarket paradise, input the first product");
        product1 = keyboard.nextInt();
        System.out.println("Input the second product");
        product2 = keyboard.nextInt();
        System.out.println("Input the third variable");
        product3 = keyboard.nextInt();
        System.out.println("Input the fourth variable");
        product4 = keyboard.nextInt();
        total_bruto = product1 + product2 + product3 + product4;
        iva = total_bruto * 0.19;
        total = total_bruto + iva;

        System.out.println("Your bill is");
        System.out.println("Total bruto: $"+total_bruto);
        System.out.println("IVA: $"+iva);
        System.out.println("Total: $"+total);
        


    }
}

package usta.sistemas;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Juan Sebastian Arias Moreno
	  DATE: 12/03/2020
	  DESCRIPTION: This software input two variable and adds
	 */
        Scanner keyboard = new Scanner(System.in);
        int v1, v2, suma;
        System.out.println("This program adds two variable, input the first variable");
        v1=keyboard.nextInt();
        System.out.println("Input the second variable");
        v2=keyboard.nextInt();
        suma=v1+v2;
        System.out.println("This sumatory is "+ suma);
    }
}

package usta.sistemas;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Juan Sebastian Arias Moreno
	  DATE: 19/03/2020
	  DESCRIPTION: This software calculate the hypotenuse of a triangle
	 */
        Scanner keyboard = new Scanner(System.in);
        double cate1, cate2, hypot;
        System.out.println("This software calculate the hypotenuse of a triangle in cm, input the first leg in cm");
        cate1 = keyboard.nextDouble();
        System.out.println("Input the second leg in cm");
        cate2 = keyboard.nextDouble();
        hypot = Math.sqrt(Math.pow(cate1,cate2)+Math.pow(cate1,cate2));
        System.out.println("The result of the hypotenuse in cm is: "+hypot);
    }
}

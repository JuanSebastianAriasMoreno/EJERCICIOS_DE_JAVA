package usta.sistemas;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Juan Sebastian Arias Moreno
	  DATE: 12/03/2020
	  DESCRIPTION: This software prints two birth years and their difference
	 */
	Scanner keyboard = new Scanner(System.in);
	int year1,year2, difference;
        System.out.println("This software prints two birth years and their difference, input the first year");
        year1=keyboard.nextInt();
        System.out.println("Input the second year");
        year2=keyboard.nextInt();
        difference=year1-year2;
        System.out.println("The difference between the two years is "+difference);
    }
}

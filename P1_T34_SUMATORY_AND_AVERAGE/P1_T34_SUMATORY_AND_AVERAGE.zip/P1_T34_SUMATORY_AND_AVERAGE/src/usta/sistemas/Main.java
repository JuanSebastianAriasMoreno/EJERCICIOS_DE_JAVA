package usta.sistemas;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Juan Sebastian Arias Moreno
	  DATE: 12/03/2020
	  DESCRIPTION: This software adds and find the average of three numbers
	 */
	Scanner keyboard = new Scanner(System.in);
	int v1, v2, v3, sumatory;
	double average;
        System.out.println("This software adds three numbers, input the first number");
        v1=keyboard.nextInt();
        System.out.println("Input the second number");
        v2=keyboard.nextInt();
        System.out.println("Input the third number");
        v3=keyboard.nextInt();
        sumatory=v1+v2+v3;
        average=sumatory/3;
        System.out.println("The sumatory is "+sumatory);
        System.out.println("The average is "+average);
    }
}

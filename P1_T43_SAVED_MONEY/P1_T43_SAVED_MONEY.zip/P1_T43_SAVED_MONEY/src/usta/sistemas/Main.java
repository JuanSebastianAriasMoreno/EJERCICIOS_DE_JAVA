package usta.sistemas;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Juan Sebastian Arias Moreno
	  DATE: 29/03/2020
	  DESCRIPTION: This software determinate how much money a person saves in a year if he save 15% of your salary and the salary don´t change
	 */
        System.out.println("----------------------------------------");
        System.out.println("                   SPY");
        System.out.println("----------------------------------------");
        double salary, saved;
        Scanner keyboard = new Scanner(System.in);
        System.out.println("This software determinate how much money a person saves in a year if he save 15% of his salary every week and the salary doesn´t change. Input the salary of the week:");
        salary = keyboard.nextDouble();
        saved = (salary*0.15)*48;
        System.out.println("The saved money of the salary is: $"+saved+ " per year");
    }
}

package usta.sistemas;

public class Main {
    /*AUTHOR: Juan Sebastian Arias Moreno
      DATE: 10/03/2020
      DESCRIPTION: This software shows a seahorse in the screen
     */

    public static void main(String[] args) {
        System.out.println("___________$$$$,,");
        System.out.println("________$$$$$$$$$$$$$");
        System.out.println("________$$$$$$$$$$$_$");
        System.out.println("_______$$$$$$$$$$$$$$");
        System.out.println("________$$$$$$$$$$$$$$");
        System.out.println("_______$$$$$$$$$$_$$$$$");
        System.out.println("______$$$$$$$$$$$____$$$$");
        System.out.println("______$$$$$$$$$$$$_____$");
        System.out.println("______$$$$$$$$$$$$$");
        System.out.println("_______$$$$$$$$$$$$$");
        System.out.println("_______$$$$$$$$$$$$$$");
        System.out.println("________$$$$$$$$$$$$$$");
        System.out.println("_$$$$_____$$$$$$$$$$$$");
        System.out.println("__$$$$$$$$$$$$$$$$$$$$");
        System.out.println("_$$$$$$$$$$$$$$$$$$$$");
        System.out.println("__$$$$$$$$$$$$$$$$$$");
        System.out.println("$$$$$$$$$$$$$$$$$$");
        System.out.println("__$__$$$$$$$$$$$");
        System.out.println("____$$$$$$$$$$");
        System.out.println("___$$$$$$$$$$");
        System.out.println("__$$$$$$$$$______$");
        System.out.println("__$$$$$$$$$___$$_$$");
        System.out.println("___$$$$$$$____$__$$");
        System.out.println("____$$$$$$_______$$");
        System.out.println("_____$$$$$$_____$$$");
        System.out.println("______$$$$$$$$$$$$");
        System.out.println("_________$$$$$$$");
    }
}

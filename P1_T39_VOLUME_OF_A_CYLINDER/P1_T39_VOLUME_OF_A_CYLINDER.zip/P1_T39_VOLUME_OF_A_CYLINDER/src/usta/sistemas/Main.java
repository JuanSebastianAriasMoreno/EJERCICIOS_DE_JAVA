package usta.sistemas;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Juan Sebastian Arias Moreno
	  DATE: 19/03/2020
	  DESCRIPTION: This software calculate the volume of a cylinder
	 */
        Scanner keyboard = new Scanner(System.in);
        double height, radius, volume;
        System.out.println("This software calculate the volume of a cylinder in cm, input the height in cm");
        height = keyboard.nextDouble();
        System.out.println("Enter the radius in cm");
        radius = keyboard.nextDouble();
        volume = 3.1416 * Math.pow(radius,2) * height;
        System.out.println("The volume of the cylinder on cm is: "+volume);
    }
}
